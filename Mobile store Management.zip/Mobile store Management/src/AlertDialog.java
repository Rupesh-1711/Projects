
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class AlertDialog {
      public void showMassage(javax.swing.JFrame jframe,String msg, String title)
{
JOptionPane.showConfirmDialog(jframe, msg, title, JOptionPane.DEFAULT_OPTION , JOptionPane.INFORMATION_MESSAGE);
}
}
