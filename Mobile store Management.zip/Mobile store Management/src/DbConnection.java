



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



public class DbConnection {
 
    static Connection con; 
	static String url; 
	public static Connection getConnection() 
	{ 
		try
		{ 
			url = "jdbc:mysql://localhost/msms";
		
			Class.forName("com.mysql.jdbc.Driver"); 
			try 
			{
				con = DriverManager.getConnection(url,"root","");
				  System.out.println("connection success");
				} 
				catch (SQLException ex)
				{ 
					} 
			} 
		catch(ClassNotFoundException e)
		{
			System.out.println(e);
			} 
		return con;
		} 
}
